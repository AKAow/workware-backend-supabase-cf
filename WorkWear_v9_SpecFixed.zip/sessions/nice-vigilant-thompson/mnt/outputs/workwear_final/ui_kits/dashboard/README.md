# WindTree Operator Dashboard — UI Kit

Fleet-wide turbine monitoring surface. Sidebar nav, top bar, KPI row, live output chart, turbine roster, alert feed. Click-through prototype: the turbine list is selectable, the time-range toggle updates the chart, filters update the list.

## Files
- `index.html` — assembled dashboard, the "typical view" of the product
- `Sidebar.jsx` — left primary navigation (240px)
- `TopBar.jsx` — search, status, profile
- `KpiRow.jsx` — four KPI blocks across the top of the content area
- `OutputChart.jsx` — area chart with 24h/7d/30d toggle
- `TurbineList.jsx` — roster with status chip + sparkline per row
- `AlertFeed.jsx` — live alerts panel (right rail)
- `Map.jsx` — mini site map placeholder

All components consume `../../colors_and_type.css` tokens. No production concerns — this is a visual/interaction kit, not real code.
