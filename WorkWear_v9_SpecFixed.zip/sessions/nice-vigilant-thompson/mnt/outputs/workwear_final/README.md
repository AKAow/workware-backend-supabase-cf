# WindTree Glass — Design System

Premium B2B glassmorphism design system for wind-energy SaaS dashboards.

**Brand identity:** Clean, high-trust, data-first. Glassmorphism on a sky-blue gradient background. One message at a time. Professional and calm — never flashy.

---

## Sources Used

- Font: `uploads/Lexend-VariableFont_wght.ttf` (variable, 100–900)
- Font: Pretendard v1.3.9 via CDN (`orioncactus/pretendard`) — Korean body + UI
- Logo PNGs: `uploads/windtree-horizontal original.png`, `windtree-stacked.png.png`, `windtree-horizontal white.png`, `windtree-horizontal just logo.png`
- No Figma link or codebase was provided — system was built from brand brief + uploaded assets.

---

## File Index

```
/
├── README.md                  ← this file
├── SKILL.md                   ← Claude Code / agent skill definition
├── colors_and_type.css        ← ALL CSS variables (color, type, spacing, shadow, radius)
├── fonts/
│   └── Lexend-VariableFont_wght.ttf
├── assets/
│   ├── logo-horizontal.png    ← primary lockup (mark + wordmark, horizontal)
│   ├── logo-stacked.png       ← stacked lockup (mark above wordmark)
│   ├── logo-horizontal-white.png ← white version for dark backgrounds
│   ├── logo-mark.png          ← mark only (drop + flame)
│   └── logo-mark.svg          ← SVG recreation (fallback only)
├── preview/                   ← Design System tab cards (700px HTML tiles)
│   ├── brand-logo.html
│   ├── colors-brand.html
│   ├── colors-semantic.html
│   ├── colors-text.html
│   ├── colors-viz.html
│   ├── components-buttons.html
│   ├── components-card.html
│   ├── components-chip.html
│   ├── components-inputs.html
│   ├── components-kpi.html
│   ├── components-nav.html
│   ├── glass-recipe.html
│   ├── radii.html
│   ├── shadows.html
│   ├── spacing-scale.html
│   ├── type-display.html
│   ├── type-kpi.html
│   └── type-scale.html
└── ui_kits/
    └── dashboard/             ← SaaS dashboard UI kit
        ├── index.html         ← interactive prototype
        ├── App.jsx
        ├── TopBar.jsx
        ├── Sidebar.jsx
        ├── KpiRow.jsx
        ├── OutputChart.jsx
        ├── AlertFeed.jsx
        ├── TurbineList.jsx
        ├── dashboard.css
        └── README.md
```

---

## CONTENT FUNDAMENTALS

**Language:** Korean (ko-KR) primary, English secondary for technical labels and global contexts.

**Tone:** Professional, direct, data-confident. Not casual. No exclamation marks. Sentences are short — data speaks for itself.

**Casing:** Title Case for headings in English. Sentence case for labels. ALL CAPS only for small tracking labels (e.g. `AVAILABILITY`, `OUTPUT`).

**Numbers:** Always formatted with comma separators (`2,340 MWh`). Units are appended with a space (`12.4 m/s`, `98.2%`). KPI numbers are dominant — text is minimal.

**Emoji:** Never used. This is a professional B2B SaaS dashboard.

**I vs You:** Neutral / system voice. Avoid "you" or "I." Write as if the dashboard is a trusted instrument, not a product pitch.

---

## VISUAL FOUNDATIONS

**Color vibe:** Cool, clean, sky-blue. Background is always a subtle sky gradient (`#F5FAFF → #EAF4FF`). Accent is WindTree Blue (`#2F80ED`). Never warm backgrounds.

**Logo gradient:** `#65A3B2 → #316074 → #042C44` (extracted from actual mark). Use for gradient buttons, slide headers, decorative elements.

**Glassmorphism recipe:**
- Background: `rgba(255,255,255,0.60)` + `backdrop-filter: blur(24px) saturate(140%)`
- Border: `1px solid #D6E8FF`
- Inner highlight: `inset 0 1px 0 rgba(255,255,255,0.70)`
- Shadow: `0 4px 16px rgba(10,37,64,0.08), 0 1px 3px rgba(10,37,64,0.06)`

**Typography:**
- Display / headings (EN): Lexend 700, −0.02em tracking, tight line-height (1.05–1.1)
- Display / headings (KO): Pretendard 700, −0.02em tracking
- Body (EN + KO): Pretendard 400, 14–16px
- KPI numerals: Lexend 600, 60–72px, tabular-nums, −0.02em
- Labels: Pretendard 500, 11–12px, 0.04–0.06em tracking, ALL CAPS

**Spacing:** 4px base unit. Scale: 4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96px.

**Border radius:** Small 8px · Medium 12px · Large 16px · XL 24px · Pill 999px

**Shadows:** Soft (`0 2px 8px rgba(10,37,64,0.06)`) → Medium (`0 4px 16px rgba(10,37,64,0.08)`) → Large (`0 12px 32px rgba(10,37,64,0.12)`)

**Animations:** Subtle fade-in (`opacity 0 → 1`, 200ms ease-out). No bouncing. No aggressive transitions. Everything feels calm.

**Hover states:** Slightly stronger glass (`rgba(255,255,255,0.78)`) + subtle shadow lift. Never color change on hover — keep it calm.

**Data visualization:** Single-hue blue ramp (`#0A2540 → #B8D4F8`). Hierarchy via stroke weight (3px → 1.2px) + solid/dashed/dotted. Warm hues (Coral `#E05555`) reserved exclusively for alerts/errors.

**Imagery:** Placeholder only — no illustrations in the system. Wind turbine imagery should be clean, high-contrast photography, not cartoons or icons.

**Backgrounds:** Always light sky gradient. No dark mode defined yet.

---

## ICONOGRAPHY

**System:** Lucide Icons (CDN: `https://unpkg.com/lucide@latest`) — stroke-based, 1.5–1.75px stroke-width, round caps/joins. Consistent with the clean, professional tone.

**Size:** 16px (inline/compact) · 20px (standard) · 24px (prominent)

**Color:** Inherits `currentColor`. Use `var(--fg-2)` for inactive, `var(--accent)` for active/selected, `var(--err)` for alerts.

**Never:** Emoji as icons. Custom hand-drawn SVG icons. Filled/solid icon style (stroke only).
